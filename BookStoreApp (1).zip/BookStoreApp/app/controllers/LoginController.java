package controllers;

import controllers.Auth.Secured;
import models.User;
import play.data.Form;
import play.data.FormFactory;
import play.mvc.Controller;
import play.mvc.Result;
import views.html.auth.login;

import javax.inject.Inject;

public class LoginController extends Controller {

    @Inject
    FormFactory formFactory;


    public Result authenticateUser(){

        Form<User> form = formFactory.form(User.class).bindFromRequest();

        String email = form.rawData().get("email");
        String password = form.rawData().get("password");

        //Checks if there is any text in the input fields
        if(email == null || password == null){
            User.errorMsgBox("Email or password is invalid" + email + " " + password, "Error");
            return redirect(routes.BooksController.index());

        }

        User user = User.find.byId(email);

        //Checks if the password is correct or if there is such user in the database
        if(user == null || !password.equals(user.getPassword())){
            User.errorMsgBox("User does not exist or password is incorrect", "Error");
            return redirect(routes.BooksController.index());
        }

        if(user.isAdmin()){
            User.errorMsgBox("Redirecting to admin home page", "Logging in...");
            return redirect(routes.BooksController.index());
        }

        User.errorMsgBox("Redirecting to your home page", "Logging in...");
        return redirect(routes.BooksController.index());
    }

    public Result login(){
        if(Secured.CHECK()){
            return redirect(routes.BooksController.index());
        }
        Form<User> form = formFactory.form(User.class);
        return ok(login.render(form));
    }

    public Result logout(){
        session().clear();
        flash("success","You've been logged out");
        return redirect(routes.BooksController.index());
    }

    public Result forgotUser() {

        Form<User> form = formFactory.form(User.class);
        return ok(login.render(form));
    }

    public Result forgotPass(){

        Form<User> form = formFactory.form(User.class);
        return ok(login.render(form));
    }

}
