# BootStore App in play 2.6.x

This is CRUD application build in play 2.6 for [Youtube Tutorials](https://goo.gl/s9mQB5). Play 2.5 App can be found here [BookStore 2.5](https://github.com/iaz33m/BookStore-App-In-Play).
