//Variable Declaration
var canadaArmLink = document.getElementById('CanadaArmButton');
var thumbnailCALink = document.getElementById('thumbnail-button-Canada-Arm');

//Event Listeners
canadaArmLink.addEventListener('click',openApplication);
thumbnailCALink.addEventListener('click', openApplication);


function openApplication(){
    params  = 'width='+screen.width;
    params += ', height='+screen.height;
    params += ', top=0, left=0';
    params += ', fullscreen=yes';
    params += ', menubar=no,location=no,status=no,scrollbar=no,resizeable=no,titlebar=no';
    window.open('/apphomepage',
        "_blank", params, false);
}