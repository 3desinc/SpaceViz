//Variables
var showUserButton = document.getElementById('ShowUsers');
var createUserButton = document.getElementById('CreateUser');
var dropUserButton = document.getElementById('DropUser');
var settingsButton = document.getElementById('Settings');
var dropUserSubmitButton = document.getElementById('dropUserSubmit');


//Event Listeners
showUserButton.addEventListener('click', function(){
    toggleDisplay("ShowUser")});

createUserButton.addEventListener('click', function(){
    toggleDisplay("CreateUser")});

dropUserButton.addEventListener('click', function(){
    toggleDisplay("DropUser")});

dropUserSubmitButton.addEventListener('click', function(){
    var dropUserId = document.getElementById('dropuserID').value;
    dropUser(dropUserId)});

settingsButton.addEventListener('click', function(){
    toggleDisplay("Settings")});

//Functions
function toggleDisplay(id) {

    if(id === "ShowUser"){

        document.getElementById('AllUsersDiv').style.display = "block";
        document.getElementById('CreateUserDiv').style.display = "none";
        document.getElementById('DropUserDiv').style.display = "none";
        document.getElementById('SettingsDiv').style.display = "none";
    }
    if(id === "CreateUser"){

        document.getElementById('AllUsersDiv').style.display = "none";
        document.getElementById('CreateUserDiv').style.display = "block";
        document.getElementById('DropUserDiv').style.display = "none";
        document.getElementById('SettingsDiv').style.display = "none";
    }
    if(id === "DropUser"){

        document.getElementById('AllUsersDiv').style.display = "none";
        document.getElementById('CreateUserDiv').style.display = "none";
        document.getElementById('DropUserDiv').style.display = "block";
        document.getElementById('SettingsDiv').style.display = "none";
    }
    if(id === "Settings"){

        document.getElementById('AllUsersDiv').style.display = "none";
        document.getElementById('CreateUserDiv').style.display = "none";
        document.getElementById('DropUserDiv').style.display = "none";
        document.getElementById('SettingsDiv').style.display = "block";
    }






}

function dropUser(userDrop) {

    var confirmDrop = confirm("Are you sure you would like to drop user: " + userDrop);
    if(confirmDrop){
        alert("Dropped User: " + userDrop);
        //execute drop
    }
}