var settingsButton = document.getElementsByClassName('setting-div-option');

settingsButton.addEventListener('click', function(){
    var settingName = settingsButton.target.id;
    changeZIndex(settingName);
});

function changeZIndex(SettingName) {
    document.getElementById(SettingName).style.zIndex = "1";
    alert("this is the setting name" + SettingName);
}
