//Event Listener password check
var passOK = document.getElementById('passwordCheck');
var submitOK = document.getElementById('userCreation');

passOK.addEventListener('click', function(){
    var pass1 = document.getElementById('password1').value;
    var pass2 = document.getElementById('password2').value;
    passCheck(pass1, pass2);
});


//Password Checker
function passCheck(pass1, pass2){

    if(pass1 === pass2){
        alert("Good Password!");
    }
    else{
        alert("Passwords do not match \n Please enter matching passwords");
    }
}

