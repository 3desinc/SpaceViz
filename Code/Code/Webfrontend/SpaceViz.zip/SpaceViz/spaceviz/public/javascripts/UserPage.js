//Variable Declaration
var logOutForm = document.getElementById('logoutForm');

//Event Listeners
logOutForm.addEventListener('submit', logOut);



function logOut(){

    var logOutOK = confirm("Are you sure you want to log out?")

    if (logOutOK){
        alert("Logging you out...");
        document.getElementById('logoutForm').action = "/loginpage";
    }
}