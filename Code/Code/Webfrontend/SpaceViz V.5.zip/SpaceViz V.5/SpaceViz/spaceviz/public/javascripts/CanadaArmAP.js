var homeButton = document.getElementById('userpage-home-Button');

homeButton.addEventListener('click', function(){
    if(confirm("Are you sure you want to leave the simulation?")){
        window.close();
    }
});
