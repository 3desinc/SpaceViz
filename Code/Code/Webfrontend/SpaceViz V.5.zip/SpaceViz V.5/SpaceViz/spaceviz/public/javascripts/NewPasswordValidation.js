//Variable
var newPasswordSubmit = document.getElementById('newPasswordSubmit');

//Event Listener
newPasswordSubmit.addEventListener('click', function(){
    var oldPassword = document.getElementById('oldPassword').value;
    newPassValid(oldPassword)});

//Function

function oldPassValid(nPass){

    if(nPass === "admin" /*SessionUser Password*/) {
        return true;
    }
    else{
        return false;
    }
}

function newPassCheck(){

    var newPass1 = document.getElementById('passwordChange').value;
    var newPass2 = document.getElementById('passwordConfirm').value;
    //Password Strength can be implemented here
    if (newPass1 === newPass2){
        return true;
    }
    else
        return false;
}

function newPassValid(nPass){

    var errorMsg = "";

    if(oldPassValid(nPass) && newPassCheck()){
        alert("Your password has been changed");
    }
    if(!oldPassValid(nPass)){
        errorMsg += "Old password is incorrect \n";
    }
    if(!newPassCheck()){
        errorMsg += "New Passwords do not match \n";
    }
    if(errorMsg.length > 0){
        alert(errorMsg)
    }



}