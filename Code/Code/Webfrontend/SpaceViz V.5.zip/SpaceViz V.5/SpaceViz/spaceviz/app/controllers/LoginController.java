package controllers;

import Models.User;
import Utility.Hash;
import play.data.Form;
import play.data.FormFactory;
import play.mvc.Controller;
import play.mvc.Http;
import play.mvc.Result;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;
import javax.mail.Session;
import javax.mail.Transport;
import javax.inject.Inject;
import java.util.Properties;

public class LoginController extends Controller {

    @Inject
    FormFactory FF;

    public Result sendEmail(String recipient, String content){

        String sender = "spaceviz.noreply.gmail.com";
        // Gmail as SMTP host
        String host = "smtp.gmail.com";

        // Getting system properties
        Properties properties = System.getProperties();

        // Setting up mail server
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", "465");

        String myAccountUsername =  "spaceviz.noreply@gmail.com";
        String myAccountPassword =  "spaceVIZ1234";

        // creating session object to get properties
        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(myAccountUsername, myAccountPassword);
            }
        });
        try
        {
            // MimeMessage object.
            MimeMessage message = new MimeMessage(session);
            // Set From Field: adding senders email to from field.
            message.setFrom(new InternetAddress(sender));

            // Set To Field: adding recipient's email to from field.
            message.setRecipient(Message.RecipientType.TO, new InternetAddress(recipient));

            // Set Subject: subject of the email
            message.setSubject("SpaceViz TEST email");

            // set body of the email.
            message.setContent("<h1>You can change your password here: " + content + "</h1>", "text/html");

            // Send email.
            Transport.send(message);
        }
        catch (MessagingException mex)
        {
            mex.printStackTrace();
        }
        return redirect(routes.HomeController.index());
    }

    public Result authenticateUser(Http.Request request){
        Form<User> form = FF.form(User.class).bindFromRequest(); //TODO Figure out bindFromRequestData

        String email = form.rawData().get("Email");
        String password = form.rawData().get("Password");

        //Checks if there is any text in the input fields
        if(email == null || password == null){
            User.errorMsgBox("Email or password is invalid" + email + " " + password, "Error");
            return redirect(routes.HomeController.index());

        }
        //Search the database for the user with the given email
        User user = User.find.byId(email);

        //User.errorMsgBox("Find Function: " + user.getPassword(), " Error");
        //return ok("This works!" + user);

        //Checks if the password is correct or if there is such user in the database
        if(user == null || !Hash.check(password,user.password)){ //Changed from user.getPassword to hash
            User.errorMsgBox("User does not exist or password is incorrect", "Error");
            return redirect(routes.HomeController.index());
        }

/*
        if(user.isAdmin()){ //TODO ADMIN check
            User.errorMsgBox("Redirecting to admin home page", "Logging in...");
            return redirect(routes.UserpageController.adminPage());
        }
*/
        //Add session keys and values associated with user that has logged in
        return redirect(routes.UserpageController.userPage())
                .addingToSession(request,"Email", email)
                .removingFromSession(request,"Secured")
                .addingToSession(request, "Secured", "True");

    }
    //TODO Currently there is no functionality for this page
    public Result forgotUser() {

        return ok(views.html.loginPage.forgotUser.render());
    }

    public Result forgotPass(){

        Form<User> form = FF.form(User.class);
        return ok(views.html.loginPage.forgotPass.render(form));
    }

    public Result forgotPassSubmit() {

        Form<User> form = FF.form(User.class).bindFromRequest();

        String email = form.rawData().get("Email");

        if (email == null) {
            User.errorMsgBox("Please provide an email", "ERROR");
            return ok(views.html.loginPage.forgotPass.render(form));
        }

        User user = User.find.byId(email);

        if (user == null) {
            User.errorMsgBox("There is no such User by that email", "ERROR");
            return ok(views.html.loginPage.forgotPass.render(form));
        }
        String userPassword = user.getPassword();
        User.errorMsgBox("An email has been sent to the email you have provided." +
                " Please follow the instructions on how to reset your password", "Success");
        return redirect(routes.LoginController.sendEmail(email, userPassword));
    }

    public Result register(){
        Form<User> form = FF.form(User.class);
        return ok(views.html.loginPage.register.render(form));
    }

    public Result save(){

        Form<User> form = FF.form(User.class).bindFromRequest();

        if(form.hasErrors()){
            User.errorMsgBox("danger","Input validation failed.");
            return redirect(routes.LoginController.register());
        }

        User user = form.get();

        try {
            user.password = Hash.create(user.password);
        } catch (Exception e) {
            User.errorMsgBox("danger",e.getMessage());
            return redirect(routes.LoginController.register());
        }

        user.save();

        return redirect(routes.HomeController.index());


    }
}
