package models;

import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

import Utility.*;

@Entity //Define the class as an entity to generate a table with
public class User extends Model {

	//Variables that will be used as the object's properties

	@Id //this becomes PK (primary key) when you use Id
	private int id;

	@Constraints.Required
	private String username;

	@Constraints.Required
	private String displayname;

	@Constraints.Required
	@Constraints.Email
	private String email;

	@Constraints.Required
	private String password;

	@Constraints.Required //Makes it so this is required when adding info to the db
	private String type;

	@Formats.DateTime(pattern="MM/dd/yyyy")
    public Date createdOn = new Date();

	public User(int id, String username, String displayname, String email, String password, String type, Date createdOn) {

		this.id = id;
		this.username = username;
		this.displayname = displayname;
		this.email = email;
		this.password = password;
		this.type = type;
		this.createdOn = createdOn;

	}

	//This can return Game by id, or other things like SQL statements
	public static final Finder<Integer,User> findUsers = new Finder<>(User.class);

	//How to declare:
	//public static final Finder<Primary Key Data Type(REFERENCE TYPE NOT PRIMITIVE TYPE),Class Name> variable name = new Finder<>(Classname.class);
	//
	//public static final Finder<PK type,TableName> find = new Finder<>(TableName.class);


	//get value methods

	public int getId() {
		return this.id;
	}
	public String getUsername() {
		return this.username;
	}
	public String getDisplayname() {
		return this.displayname;
	}
	public String getEmail() {
		return this.email;
	}
	public String getPassword() {
		return this.password;
	}
	public String getType() {
		return this.type;
	}
	public String getCreatedOn() {
		String date = this.createdOn.toString();
		return date;
	}

	//set value methods

	public void setId(int id) {
		this.id = id;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public void setDisplayname(String displayname) {
		this.displayname = displayname;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void setType(String type) {
		this.type = type;
	}


	//User Modification and Validation methods


	//http://www.devthoughts.pl/2017/05/19/playing-with-play-ebean/
	public static boolean create(String username, String displayname, String email, String password, String type) {

		List<User> list = User.findUsers.all(); //Obtain every user object from the DB and make a list

		//int lastId = listMaxIndex(list);

		Random rng = new Random(); //Create a new random object

		final int RNG_RANGE = 100000000; //Variable for random object nextInt() range

		//Original range: 100000000

		int id = rng.nextInt(RNG_RANGE); //Generate a random number in the interval [1, 99999999] and set it to "id"
										//Why not [0,99999999]? This is because for some reason 0 does not get inserted into the DB
										//Therefore, 0 must be populated manually in the boolean array or there must be a
										//placeholder account with ID 0 in the DB for the following to work

		boolean[] ids = new boolean[RNG_RANGE]; //Create a boolean array with every possible id outcome [0, 99999999]
												//If an ID has been used already, that index should be set to true

		//ids[0] = true;


								//For each user object in the list
								// - Obtain their ID
								// - Use their ID as an index in the ids array
								// - Check if that index is set to false, if so make it true
								//This makes sure the program is keeping track of every ID previously taken
		for (User user: list) {
			if (ids[user.getId()] == false) {
				ids[user.getId()] = true;
			}
		}

		if (areAllTrue(ids)) { //If the boolean array is all true (every ID is taken) then the method will return false

			return false;

		} else {

										//NOW, take the randomly generated ID and use it as the index in the ids array
										//Check if it is true, and if so enter the loop because this means it is taken
										//Regenerate new IDs until one which is false is found. This means its not taken
										//At least ONE available ID should exist because this portion of the program
										//cannot be accessed if 0 options exist (an infinite loop will occur if it's accessed)
			while (ids[id] == true) {
				id = rng.nextInt(RNG_RANGE);
			}

			Date D_O_C = new Date();

			password = Hash.create(password);

			User u = new User(id, username, displayname, email, password, type, D_O_C); //Finally use the ID to create a new user object
			
			u.insert(); //Insert the object into the DB

			return true; //Return true if everything was completed

		}
		
	}

	public static void destroy(String username) {
		User u = findUsers.query()
				.where()
				.eq("username", username)
				.findOne();

		u.delete();
	}

	public static boolean doesUsernameExist(String username) {

		List<User> usersList = User.findUsers.all();

		int matchCounter = 0;

		for (User user: usersList) {
			if (user.getUsername().equals(username)) {
				matchCounter++;
			}
		}

		if (matchCounter > 0) {
			return true;
		} else {
			return false;
		}

	}

	public static boolean doesEmailExist(String email) {

		List<User> usersList = User.findUsers.all(); //Get a list of every user object

		int matchCounter = 0; //Create counter

		//For every user object in the list of users, if a match exists between the email input
		//and an object's email in the list, increment the counter

		for (User user: usersList) {
			if (user.getEmail().equals(email)) {
				matchCounter++;
			}
		}

		if (matchCounter > 0) { //If there is a match, return true. Otherwise return false.
			return true;
		} else {
			return false;
		}

	}

	public static boolean areAllTrue(boolean[] array) {

									//For each boolean pointer in a boolean array
									//if there exists a pointer which points to a false value
									//return false.
									//This means one false value exists and therefore the
									//boolean array is not filled with pointers pointing to true
	    for(boolean b : array) {
	    	if(!b) return false;
	    }
	    				//Return true if every boolean pointer is checked.
	    				//For this point to be reached, no such boolean variable exists which satisfies
	    				//the condition (!b) (meaning no values are false in the array, everything is true)
	    return true;

	}

	//Editing Methods

}