package models;

import java.util.*;
import javax.persistence.*;

import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

@Entity //Define the class as an entity to generate a table with
public class Game extends Model {

	//Variables that will be used as the object's properties

	@Id //this becomes PK (primary key) when you use Id
	private int id;

	@Constraints.Required
	private String name;

	@Constraints.Min(0) //When adding info the db, this must contain a value and it cannot be less than 0
	private double price;

	@Constraints.Required //Makes it so this is required when adding info to the db
	private String category;

	@Constraints.Required //Makes it so this is required when adding info to the db
	private String rating;

	public Game(int id, String name, double price, String category, String rating) {

		this.id = id;
		this.name = name;
		this.price = price;
		this.category = category;
		this.rating = rating;

	}

	public static final Finder<Integer,Game> findGames = new Finder<>(Game.class);


	//get value methods

	public int getId() {
		return this.id;
	}
	public String getName() {
		return this.name;
	}
	public double getPrice() {
		return this.price;
	}
	public String getCategory() {
		return this.category;
	}
	public String getRating() {
		return this.rating;
	}

	//set value methods

	public void setId(int id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}

}