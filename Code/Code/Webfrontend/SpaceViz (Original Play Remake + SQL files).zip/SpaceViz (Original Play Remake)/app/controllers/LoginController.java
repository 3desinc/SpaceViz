package controllers;

import play.mvc.*;
import play.data.*;
import models.*;
import controllers.*;

import play.mvc.Security;

import play.db.ebean.Transactional;
import java.util.ArrayList;
import java.util.List;

import views.html.*;
import views.html.login.*;

import javax.inject.*;
import play.data.FormFactory;

import com.avaje.ebean.*;
import io.ebean.*;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import Utility.*;

/*
 * This controller contains an action to handle HTTP requests
 */

public class LoginController extends Controller {

    @Inject FormFactory form;

    public Result login(Http.Request request) {

        Form<User> loginForm = form.form(User.class);

        String secured = request.session().data().get("secured");
        String uid = request.session().data().get("connected");


        if ("true".equals(secured)) {
            return redirect(routes.HomeController.profile(uid));
        } else {
            return ok(login.render(loginForm, request.flash().getOptional("danger").orElse(""), secured, uid));
        }
    }

    public Result validate(Http.Request request) {

        Form<User> bind = form.form(User.class).bindFromRequest(request); //Save POST data in this variable

        String displayname = bind.rawData().get("username"); //Get raw data from field named "username" and put it in a string
        String password = bind.rawData().get("password"); //Get raw data from field named "password" and put it in a string


        String username = displayname.toLowerCase();

        String errorString = ""; //Create a variable to chain error messages to

        int matchCounter = 0; //Counter to count the number of matches the username has to users in the DB

        List<User> userList = User.findUsers.all(); //Retreive list of all users in DB

        for (User user: userList) { //For each object in the list of objects
            if (user.getUsername().equals(username)) { //If the object username matches with user input
                matchCounter++; //increment one match
            }
        }

        if (matchCounter > 0) { //If matches exist, query to find one entity matching that username

            //Create a new User object called u

             User u = User.findUsers //Call the findUsers finder
                    .query() //Lets you know a query is beginning
                    .where() //Where
                    .eq("username", username) //Use this to search the column, then the value you want to find
                    .findOne(); //Find ONE specific entity that contains the thing you want to find and save all other info of the entity in u

            String usernameDB = u.getUsername(); //Get entity username
            String passwordDB = u.getPassword(); //Get entity password


            if (!(usernameDB.equals(username) && Hash.check(password, passwordDB))) {

                if (!(usernameDB.equals(username))) {
                    errorString += "Username is incorrect!";
                } else if (!(Hash.check(password, passwordDB))) {
                    errorString += "Password is incorrect!";
                } else {
                    errorString += "Username and password are incorrect!";
                }

                return redirect(routes.LoginController.login()).flashing("danger", errorString);
            }

            //If everything succeeds, the if statement will be avoided
            //Then, it will redirect to the home page
            //  - Then it will remove the old "secured" key which contains "false"
            //  - It will add a new "secured" key which contains "true"
            //  - It will also add a "connected" key which contains the username
            //  - A message will be stored in flash in the key "success" saying the login was successful

            u.setDisplayname(displayname);
            u.update();

            return redirect(routes.HomeController.index())
                .removingFromSession(request, "secured")
                .addingToSession(request, "secured", "true")
                .addingToSession(request, "connected", displayname)
                .flashing("success", "\"" + displayname + "\" logged in successfully!");

        } else { //If the matchCounter is still 0, that means no users exist with the username specified

            errorString += "User does not exist!";
            return redirect(routes.LoginController.login())
            .flashing("danger", errorString);
        }
    }


    public Result create(Http.Request request) {

        Form<User> bind = form.form(User.class).bindFromRequest(request); //Store all POST data in this variable "bind"

        String displayname = bind.rawData().get("username");
        String email = bind.rawData().get("email");
        String password = bind.rawData().get("password");
        String type = bind.rawData().get("type");

        String username = displayname.toLowerCase();


        //Pattern checkers

        String errorString = "";

        if (User.doesUsernameExist(username) || User.doesEmailExist(email) || username.length() < 3 || validUsername) {

            if (validUsername) {
                if (errorString.length() > 0) {
                    errorString += " Username can only contain characters A-Z, 0-9, and _!";
                } else {
                    errorString += "Username can only contain characters A-Z, 0-9, and _!";
                }
            }
                        
            if (username.length() < 3) {
                if (errorString.length() > 0) {
                    errorString += " Your username cannot be less than 3 characters!";
                } else {
                    errorString += "Your username cannot be less than 3 characters!";
                }
            } 

            if (User.doesUsernameExist(username)) {
                if (errorString.length() > 0) {
                    errorString += " Username is already in use!";
                } else {
                    errorString += "Username is already in use!";
                }
            } 

            if (User.doesEmailExist(email)) {
                if (errorString.length() > 0) {
                    errorString += " Email is already in use!";
                } else {
                    errorString += "Email is already in use!";
                }
            }

            return redirect(routes.LoginController.login()).flashing("danger", errorString);

        } else {
            boolean userCreationStatus = User.create(username, displayname, email, password, type);

            //return ok(create.render("new user made"));
            if (userCreationStatus) {
                return redirect(routes.HomeController.index())
                    .flashing("success", "Your account has been created! Check your email to complete registration.");
            } else {
                return redirect(routes.LoginController.login())
                    .flashing("danger", "Max ID capacity reached! Please report this error.");
            }
        }
    }

    public Result logout(Http.Request request) {

        String secured = request.session().data().get("secured");
        String uid = request.session().data().get("connected");

        if ("true".equals(secured)) {
            return redirect(routes.HomeController.index())
                .withNewSession()
                .addingToSession(request, "secured", "false")
                .flashing("success", "You have logged out successfully!");
        } else {
            return redirect(routes.HomeController.index());
        }
    }

    public Result deleteAccount(Http.Request request) {

        String secured = request.session().data().get("secured");
        String uid = request.session().data().get("connected");

        String username = uid.toLowerCase();

        if ("true".equals(secured)) {

            User u = User.findUsers
                    .query() 
                    .where() 
                    .eq("username", username)
                    .findOne();

            u.destroy(uid);

            return redirect(routes.HomeController.index())
                .withNewSession()
                .addingToSession(request, "secured", "false")
                .flashing("success", "Your account has been deleted and you have been logged out.");
            
        } else {
            return redirect(routes.HomeController.index());
        }
                    
    }

    public Result editAccount(Http.Request request) {

        String secured = request.session().data().get("secured");
        String uid = request.session().data().get("connected");

        if ("true".equals(secured)) {

            Form<User> bind = form.form(User.class).bindFromRequest(request);
            String displayname = bind.rawData().get("username");

            String username = displayname.toLowerCase();

            String uidL = uid.toLowerCase();

            String errorString = "";

            Pattern usernameStandard = Pattern.compile("[^A-Za-z0-9_]");
            Matcher matcher1 = usernameStandard.matcher(username);
            boolean validUsername = matcher1.find();


            if (User.doesUsernameExist(username) || validUsername) {

                if (User.doesUsernameExist(username)) {
                    if (errorString.length() > 0) {
                        errorString += " Username already in use!";
                    } else {
                        errorString += "Username already in use!";
                    }
                } 

                if (validUsername) {
                    if (errorString.length() > 0) {
                        errorString += " Invalid username!";
                    } else {
                        errorString += "Invalid username!";
                    }
                } 

                return redirect(routes.HomeController.profile(uid))
                    .flashing("danger", errorString);

            } else {

                User u = User.findUsers
                        .query() 
                        .where() 
                        .eq("username", uidL)
                        .findOne();

                u.setUsername(username);
                u.setDisplayname(displayname);
                u.update();

                return redirect(routes.HomeController.index())
                    .removingFromSession(request, "connected")
                    .addingToSession(request, "connected", displayname)
                    .flashing("success", "Your username has been updated successfully!");
            }

        } else {

            return redirect(routes.HomeController.index());
        }

    }
 
}