package controllers;

import play.mvc.*;
import play.data.*;
import models.*;

import play.mvc.Security;

import play.db.ebean.Transactional;
import java.util.ArrayList;
import java.util.List;

import views.html.*;
import views.html.login.*;
import controllers.*;

import javax.inject.*;
import play.data.FormFactory;
import io.ebean.*;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class HomeController extends Controller {

    @Inject FormFactory form;

    /**
     * An action that renders an HTML page with a welcome message.
     * The configuration in the <code>routes</code> file means that
     * this method will be called when the application receives a
     * <code>GET</code> request with a path of <code>/</code>.
     */
    public Result index(Http.Request request) {

    	List<Game> gameList = Game.findGames.all();

        String secured = request.session().data().get("secured");
        String displayname = request.session().data().get("connected");

        return ok(views.html.index.render(gameList, request.flash().getOptional("success").orElse(""), secured, displayname));

        //, request.flash().getOptional("success").orElse("empty")
    }

    public Result profile(Http.Request request, String user) {

        Form<User> editForm = form.form(User.class);

        List<User> userList = User.findUsers.all();

        String secured = request.session().data().get("secured");
        String displayname = request.session().data().get("connected");

        String username = user.toLowerCase();


        int matchCounter = 0;

        for (User userObj: userList) {
            if (userObj.getUsername().equals(username)) {
                matchCounter++;
            }
        }

        if (matchCounter > 0) {

            User u = User.findUsers.query()
                    .where()
                    .eq("username", username)
                    .findOne();

            if (u.getDisplayname().equals(displayname)) {
                return ok(profileActive.render(editForm, request.flash().getOptional("danger").orElse(""), secured, displayname, user));
                
            } else {

                String displaynameDB = u.getDisplayname();

                return ok(profile.render(secured, displayname, displaynameDB));
            }
        } else {
            return ok(profile.render(secured, displayname, "User does not exist!"));
        }
    }

    public Result users(Http.Request request) {

        List<User> userList = User.findUsers.all();

        String secured = request.session().data().get("secured");
        String displayname = request.session().data().get("connected");

        if ("true".equals(secured)) {

            String username = displayname.toLowerCase();

            return ok(users.render(userList, secured, displayname));
        } else {
            return ok(users.render(userList, secured, " "));
        }

        
    }

    public Result settings(Http.Request request) {

        List<User> userList = User.findUsers.all();

        String secured = request.session().data().get("secured");
        String displayname = request.session().data().get("connected");

        if ("true".equals(secured)) {

            String username = displayname.toLowerCase();

            return ok(users.render(userList, secured, displayname));
            
        } else {
            return redirect(routes.HomeController.index());
        }

        
    }

}
