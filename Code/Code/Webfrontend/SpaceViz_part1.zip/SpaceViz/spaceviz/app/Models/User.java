package Models;

import io.ebean.Finder;
import io.ebean.Model;
import play.data.validation.Constraints;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.swing.*;


@Entity
@Table(name = "users")
public class User extends Model {

    //Attributes
    @Id
  /*@Constraints.Required
    public String firstName;

    @Constraints.Required
    public String lastName;
*/
    @Constraints.Email
    @Constraints.Required
    public String email;

    @Constraints.Required
    public String password;

/*
    @Constraints.Required
    public boolean admin;

    @Constraints.Required
    public boolean student;

    @Constraints.Required
    public boolean superAdmin;

    @Constraints.Required
    public boolean sysAdmin;
*/
    //Methods

    public static Finder<String, User> find = new Finder<>(User.class);

    public String getPassword(){

        return password;
    }

    public void setPassword(String password){

        this.password = password;
    }

    public static void errorMsgBox(String msgString, String titlebar){

        JOptionPane.showMessageDialog(null, msgString, "Infobox: " + titlebar, JOptionPane.INFORMATION_MESSAGE);
    }
}
