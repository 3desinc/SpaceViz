package controllers;

import Models.User;
import play.data.Form;
import play.data.FormFactory;
import play.mvc.*;

import javax.inject.Inject;


public class HomeController extends Controller {

    @Inject
    FormFactory ff;

    public Result index(Http.Request request) {

        Form<User> form = ff.form(User.class);
        return ok(views.html.index.render(form))
                .addingToSession(request, "Secured", "False");
    }

}
